import shutil


# shutil.move("Test","C:/Users/Shreyash/Desktop/") # this moves the folder or file to destinaton 
# shutil.copy('test1.txt','test2.txt') # this copies the content of file one to another 
# shutil.copy2('text1.txt','test3.txt') # this copies the content of file and preserves its metadata
# shutil.copytree('project_shutil','project_shutil_backup') #this copies the folder and stores it in same folder 
#shutil.rmtree('project_shutil_backup') # this deletes the folder completed and no backup not even in recycle bin 
shutil.make_archive('project_shutil','zip') #this method creates the ZIP/TAR 








